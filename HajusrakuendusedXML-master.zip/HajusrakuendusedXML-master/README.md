# HajusrakuendusedXML iseseisev töö

Tegin iseseisva töö kodus. Tunnis öeldu järgi sain aru, et peaks tegema rakeduse, mis lubab vaadata koolis tehtud menu.xml faili. Tegin sellise rakenduse nodeJs-is kasutades expressi. Kuna saime vahepeal uue ül. jääb see siin pooleli.

## Kuidas tööle panna

```
npm -i
```
```
nodemon start
```
Nüüd võib minna ja vaadata, mis toimub: http://localhost:3000/
